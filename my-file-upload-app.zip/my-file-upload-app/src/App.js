import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [reportName, setReportName] = useState('');
  const [subGroupId, setSubGroupId] = useState('');
  const [reportType, setReportType] = useState('');
  const [subGroups, setSubGroups] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchSubGroups = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/reports/subgroups');
        setSubGroups(response.data);
        console.log('Subgroups:', response.data);
      } catch (error) {
        setMessage('Error fetching subgroups: ' + error.message);
      }
    };
    fetchSubGroups();
  }, []);

  const onFileUpload = async () => {
    if (!reportName || !subGroupId || !reportType) {
      setMessage('Please fill all fields.');
      return;
    }

    const reportData = {
      name: reportName,
      type: reportType,
      subGroupId: parseInt(subGroupId),
    };

    try {
      const response = await axios.post('http://localhost:8080/api/reports/upload', reportData, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      setMessage(response.data);
      setReportName('');
      setSubGroupId('');
      setReportType('');
    } catch (error) {
      setMessage('Error uploading report: ' + (error.response?.data || error.message));
      console.error('Upload error:', error.response?.data, error.message);
    }
  };

  return (
    <div className="App">
      <h1>File Upload</h1>
      <div>
        <label>
          Report Name:
          <input
            type="text"
            value={reportName}
            onChange={(e) => setReportName(e.target.value)}
          />
        </label>
      </div>
      <div>
        <label>
          Subgroup:
          <select value={subGroupId} onChange={(e) => setSubGroupId(e.target.value)}>
            <option value="">Select Subgroup</option>
            {subGroups.map((subGroup) => (
              <option key={subGroup.subGroupId} value={subGroup.subGroupId}>
                {subGroup.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div>
        <label>
          Report Type:
          <select value={reportType} onChange={(e) => setReportType(e.target.value)}>
            <option value="">Select Type</option>
            <option value="PDF">PDF</option>
            <option value="Excel">Excel</option>
            <option value="CSV">CSV</option>
          </select>
        </label>
      </div>
      <button onClick={onFileUpload}>Upload</button>
      {message && <p>{message}</p>}
    </div>
  );
}

export default App;