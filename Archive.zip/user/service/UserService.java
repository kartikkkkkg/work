package project.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import project.user.dto.DashboardResponse;
import project.user.dto.NotificationDTO;
import project.user.model.Favorite;
import project.user.model.Notification;
import project.user.model.Report;
import project.user.model.SubGroup;
import project.user.model.UserSubGroup;
import project.user.repository.FavoriteRepository;
import project.user.repository.NotificationRepository;
import project.user.repository.ReportRepository;
import project.user.repository.SubGroupRepository;
import project.user.repository.UserSubGroupRepository;
import project.user.repository.UserRepository;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final UserSubGroupRepository userSubGroupRepository;
    private final ReportRepository reportRepository;
    private final FavoriteRepository favoriteRepository;
    private final SubGroupRepository subGroupRepository;
    private final NotificationRepository notificationRepository;

    @Autowired
    public UserService(UserRepository userRepository, UserSubGroupRepository userSubGroupRepository, ReportRepository reportRepository, FavoriteRepository favoriteRepository, SubGroupRepository subGroupRepository, NotificationRepository notificationRepository) {
        this.userRepository = userRepository;
        this.userSubGroupRepository = userSubGroupRepository;
        this.reportRepository = reportRepository;
        this.favoriteRepository = favoriteRepository;
        this.subGroupRepository = subGroupRepository;
        this.notificationRepository = notificationRepository;
    }

    public Optional<DashboardResponse> getDashboardData(Long userId) {
        if (userRepository.findById(userId).isEmpty()) {
            return Optional.empty();
        }
        List<UserSubGroup> userSubGroups = userSubGroupRepository.findByUserId(userId);
        Set<Integer> subGroupIds = userSubGroups.stream().map(UserSubGroup::getSubGroupId).collect(Collectors.toSet());
        List<Report> userReports = reportRepository.findBySubGroupIdIn(subGroupIds);
        List<Favorite> userFavorites = favoriteRepository.findByUserId(userId);
        List<SubGroup> userFolders = subGroupRepository.findAllById(subGroupIds);

        DashboardResponse response = new DashboardResponse();
        response.setReports(userReports);
        response.setFavorites(userFavorites);
        response.setFolders(userFolders);

        return Optional.of(response);
    }

    public List<Report> searchReports(Long userId, String query, String filter) {
        List<UserSubGroup> userSubGroups = userSubGroupRepository.findByUserId(userId);
        Set<Integer> subGroupIds = userSubGroups.stream().map(UserSubGroup::getSubGroupId).collect(Collectors.toSet());
        LocalDate today = LocalDate.now();
        Date startDate = null;

        switch (filter) {
            case "Last 7 days":
                startDate = Date.from(today.minusDays(7).atStartOfDay(ZoneId.systemDefault()).toInstant());
                break;
            case "Last 30 days":
                startDate = Date.from(today.minusDays(30).atStartOfDay(ZoneId.systemDefault()).toInstant());
                break;
            case "Custom Range":
            case "All Time":
            default:
                return reportRepository.findBySubGroupIdInAndNameContainingIgnoreCase(subGroupIds, query);
        }
        return reportRepository.findBySubGroupIdInAndNameContainingIgnoreCaseAndDateAfter(subGroupIds, query, startDate);
    }

    public void favoriteReport(Long userId, Integer reportId) {
        if (favoriteRepository.findByUserIdAndReportId(userId, reportId).isEmpty()) {
            Favorite favorite = new Favorite();
            favorite.setUserId(userId);
            favorite.setReportId(reportId);
            favoriteRepository.save(favorite);
        }
    }

    public void unfavoriteReport(Long userId, Integer reportId) {
        Optional<Favorite> favorite = favoriteRepository.findByUserIdAndReportId(userId, reportId);
        favorite.ifPresent(favoriteRepository::delete);
    }

    public Optional<Resource> downloadReport(Integer reportId) {
        Optional<Report> reportOptional = reportRepository.findById(reportId);
        if (reportOptional.isPresent()) {
            String filePath = reportOptional.get().getFilePath();
            try {
                Path file = Paths.get(filePath);
                Resource resource = new UrlResource(file.toUri());
                if (resource.exists() && resource.isReadable()) {
                    return Optional.of(resource);
                } else {
                    System.err.println("File not found or not readable: " + filePath);
                }
            } catch (MalformedURLException e) {
                System.err.println("Invalid file path: " + filePath);
                e.printStackTrace();
            }
        } else {
            System.err.println("Report not found for ID: " + reportId);
        }
        return Optional.empty();
    }

    public void addNewReport(Report report) {
        Report newReport = reportRepository.save(report);
        List<UserSubGroup> userSubGroups = userSubGroupRepository.findBySubGroupId(newReport.getSubGroupId());
        userSubGroups.forEach(userSubGroup -> {
            Notification notification = new Notification();
            notification.setUserId(userSubGroup.getUserId());
            notification.setReportId(newReport.getReportId());
            notificationRepository.save(notification);
        });
    }

    // UPDATED METHOD: Now returns a list of NotificationDTO
    public List<NotificationDTO> getNotifications(Long userId) {
        List<Notification> notifications = notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
        Set<Integer> reportIds = notifications.stream()
                .map(Notification::getReportId)
                .collect(Collectors.toSet());

        List<Report> reports = reportRepository.findAllById(reportIds);
        Map<Integer, Report> reportMap = reports.stream()
                .collect(Collectors.toMap(Report::getReportId, report -> report));

        return notifications.stream()
                .map(notif -> {
                    NotificationDTO dto = new NotificationDTO();
                    dto.setNotificationId(notif.getNotificationId());
                    dto.setReportId(notif.getReportId());
                    dto.setCreatedAt(notif.getCreatedAt().toString());

                    Report report = reportMap.get(notif.getReportId());
                    if (report != null) {
                        dto.setReportName(report.getName());
                        dto.setReportType(report.getType());
                        dto.setFolderName(report.getFolder());
                    } else {
                        dto.setReportName("Report not found");
                        dto.setReportType("N/A");
                        dto.setFolderName("N/A");
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }
}