package project.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.user.dto.DashboardResponse;
import project.user.dto.NotificationDTO;
import project.user.model.Notification;
import project.user.model.Report;
import project.user.repository.ReportRepository;
import project.user.service.UserService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class UserController {

    private final UserService userService;
    private final ReportRepository reportRepository;

    @Autowired
    public UserController(UserService userService, ReportRepository reportRepository) {
        this.userService = userService;
        this.reportRepository = reportRepository;
    }

    @GetMapping("/dashboard/{userId}")
    public ResponseEntity<DashboardResponse> getDashboardData(@PathVariable Long userId) {
        Optional<DashboardResponse> dashboardData = userService.getDashboardData(userId);
        return dashboardData.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/reports/search")
    public ResponseEntity<List<Report>> searchReports(
            @RequestParam Long userId,
            @RequestParam String query,
            @RequestParam(defaultValue = "All Time") String filter) {
        List<Report> reports = userService.searchReports(userId, query, filter);
        return ResponseEntity.ok(reports);
    }

    @PutMapping("/reports/favorite/{reportId}")
    public ResponseEntity<String> favoriteReport(@PathVariable Integer reportId, @RequestParam Long userId) {
        userService.favoriteReport(userId, reportId);
        return ResponseEntity.ok("Favorited report with ID: " + reportId);
    }

    @DeleteMapping("/reports/favorite/{reportId}")
    public ResponseEntity<String> unfavoriteReport(@PathVariable Integer reportId, @RequestParam Long userId) {
        userService.unfavoriteReport(userId, reportId);
        return ResponseEntity.ok("Unfavorited report with ID: " + reportId);
    }

    @GetMapping("/reports/{reportId}/download")
    public ResponseEntity<Resource> downloadReport(@PathVariable Integer reportId, @RequestParam(required = false, defaultValue = "false") boolean view) {
        Optional<Resource> resourceOptional = userService.downloadReport(reportId);
        if (resourceOptional.isPresent()) {
            Resource resource = resourceOptional.get();
            String fileName = resource.getFilename();
            String disposition = view ? "inline" : "attachment";
            return ResponseEntity.ok()
                    .contentType(MediaType.TEXT_PLAIN)
                    .header(HttpHeaders.CONTENT_DISPOSITION, disposition + "; filename=\"" + fileName + "\"")
                    .body(resource);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/notifications/{userId}")
    public ResponseEntity<List<NotificationDTO>> getNotifications(@PathVariable Long userId) {
        List<NotificationDTO> notifications = userService.getNotifications(userId);
        return ResponseEntity.ok(notifications);
    }


}