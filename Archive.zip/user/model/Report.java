package project.user.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Entity
@Table(name = "reports")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "report_id")
    private Integer reportId;
    private String name;
    private String type; // PDF, Excel, CSV
    private Date date;
    private String folder; // same as SubGroup name
    @Column(name = "sub_group_id")
    private Integer subGroupId;
    @Column(name = "file_path")
    private String filePath;
}