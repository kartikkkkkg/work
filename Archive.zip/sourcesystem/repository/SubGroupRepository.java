package project.sourcesystem.repository;

import project.sourcesystem.model.SubGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SubGroupRepository extends JpaRepository<SubGroup, Integer> {
    List<SubGroup> findByGroupId(Integer groupId);
}
