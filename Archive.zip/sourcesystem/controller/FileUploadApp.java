package project.sourcesystem.controller;

import project.sourcesystem.model.Report;
import project.sourcesystem.model.SubGroup;
import project.sourcesystem.repository.ReportRepository;
import project.sourcesystem.repository.SubGroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootApplication(scanBasePackages = "project.sourcesystem")
@EnableJpaRepositories(basePackages = "project.sourcesystem.repository")
@EntityScan(basePackages = "project.sourcesystem.model")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
@RestController
@RequestMapping("/api/reports")
public class FileUploadApp {

    @Autowired
    private ReportRepository reportRepository;

    @Autowired
    private SubGroupRepository subGroupRepository;

    private static final String UPLOAD_DIR = "/Users/kartikgupta/Downloads/uploaded_files";

    public static void main(String[] args) {
        SpringApplication.run(FileUploadApp.class, args);
    }

    @GetMapping("/subgroups")
    public ResponseEntity<List<SubGroup>> getAllSubgroups() {
        try {
            List<SubGroup> subgroups = subGroupRepository.findAll();
            System.out.println("Fetched subgroups: " + subgroups);
            return ResponseEntity.ok(subgroups);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(new ArrayList<>(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestBody ReportRequest request) {
        try {
            System.out.println("Received request: " + request);

            // Validate request
            if (request.getName() == null || request.getName().isEmpty() ||
                    request.getType() == null || request.getType().isEmpty() ||
                    request.getSubGroupId() == null) {
                return new ResponseEntity<>("Invalid input: All fields (name, type, subGroupId) are required.", HttpStatus.BAD_REQUEST);
            }

            // Verify subGroupId exists and fetch SubGroup name for folder
            SubGroup subGroup = subGroupRepository.findById(request.getSubGroupId())
                    .orElse(null);
            if (subGroup == null) {
                return new ResponseEntity<>("Invalid subGroupId: Subgroup does not exist.", HttpStatus.BAD_REQUEST);
            }
            String folder = subGroup.getName();
            if (folder == null || folder.isEmpty()) {
                return new ResponseEntity<>("Subgroup name (folder) cannot be null or empty.", HttpStatus.BAD_REQUEST);
            }

            // Determine file extension and content based on type
            String baseFileName = request.getName().replaceAll("\\s", "_");
            String extension;
            String content;
            if (request.getType().equalsIgnoreCase("CSV")) {
                extension = ".csv";
                // Generate valid CSV content
                content = "Name,Type,SubGroupId,Date\n" +
                        "\"" + request.getName() + "\"," +
                        request.getType() + "," +
                        request.getSubGroupId() + "," +
                        new Date() + "\n";
            } else {
                // Use .txt for PDF and Excel to avoid invalid formats
                extension = ".txt";
                content = "This is a dummy " + request.getType() + " report for " + request.getName() +
                        "\nGenerated on: " + new Date() +
                        "\nSubGroup: " + folder;
            }

            // Generate file name with conflict handling
            Path filePath = Paths.get(UPLOAD_DIR, baseFileName + extension);
            int counter = 1;
            while (Files.exists(filePath)) {
                String newFileName = baseFileName + "_" + counter + extension;
                filePath = Paths.get(UPLOAD_DIR, newFileName);
                counter++;
            }

            // Create the directory if it doesn't exist
            Path uploadPath = Paths.get(UPLOAD_DIR);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
                System.out.println("Created directory: " + uploadPath);
            }

            // Create the dummy file
            Files.write(filePath, content.getBytes());
            System.out.println("Dummy file created at: " + filePath);

            // Save report metadata to the database
            Report newReport = new Report();
            newReport.setName(request.getName());
            newReport.setType(request.getType());
            newReport.setDate(new Date());
            newReport.setFolder(folder);
            newReport.setFilePath(filePath.toString());
            newReport.setSubGroupId(request.getSubGroupId());
            reportRepository.save(newReport);
            System.out.println("Report saved to database: " + newReport);

            return new ResponseEntity<>("Dummy report created and saved to DB successfully!", HttpStatus.OK);

        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to create dummy report: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("Unexpected error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public static class ReportRequest {
        private String name;
        private String type;
        private Integer subGroupId;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public Integer getSubGroupId() {
            return subGroupId;
        }

        public void setSubGroupId(Integer subGroupId) {
            this.subGroupId = subGroupId;
        }

        @Override
        public String toString() {
            return "ReportRequest{name='" + name + "', type='" + type + "', subGroupId=" + subGroupId + "}";
        }
    }
}